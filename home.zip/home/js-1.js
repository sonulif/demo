console.log("This is My First JS page");
console.log(4*3);
//console.clear();
